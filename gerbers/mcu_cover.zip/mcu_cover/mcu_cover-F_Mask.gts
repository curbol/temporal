%TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*%
%TF.CreationDate,2025-11-17T00:26:11-08:00*%
%TF.ProjectId,mcu_cover,6d63755f-636f-4766-9572-2e6b69636164,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2025-11-17 00:26:11*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.100000*%
G04 APERTURE END LIST*
D10*
%TO.C,MH1*%
X149481621Y-86384597D03*
%TD*%
%TO.C,MH2*%
X163481621Y-94464597D03*
%TD*%
M02*
