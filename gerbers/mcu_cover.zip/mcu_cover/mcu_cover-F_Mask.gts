%TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*%
%TF.CreationDate,2025-11-02T09:09:35-08:00*%
%TF.ProjectId,mcu_cover,6d63755f-636f-4766-9572-2e6b69636164,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2025-11-02 09:09:35*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.100000*%
G04 APERTURE END LIST*
D10*
%TO.C,MH1*%
X151292203Y-89530666D03*
%TD*%
%TO.C,MH2*%
X165292203Y-96030666D03*
%TD*%
M02*
