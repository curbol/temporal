%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*%
%TF.CreationDate,2026-08-24T23:38:55-07:00*%
%TF.ProjectId,mcu_cover,6d63755f-636f-4766-9572-2e6b69636164,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-24 23:38:55*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.300000*%
G04 APERTURE END LIST*
D10*
%TO.C,MH2*%
X273539872Y-175289966D03*
%TD*%
%TO.C,MH1*%
X259939872Y-167435966D03*
%TD*%
M02*
