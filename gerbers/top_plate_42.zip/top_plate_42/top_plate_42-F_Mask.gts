%TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*%
%TF.CreationDate,2025-11-20T22:42:31-08:00*%
%TF.ProjectId,top_plate_42,746f705f-706c-4617-9465-5f34322e6b69,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2025-11-20 22:42:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,5.100000*%
G04 APERTURE END LIST*
D10*
%TO.C,MH1*%
X90422580Y-46999763D03*
%TD*%
%TO.C,MH2*%
X127072580Y-45999763D03*
%TD*%
%TO.C,MH3*%
X143224541Y-97720298D03*
%TD*%
%TO.C,MH4*%
X104300819Y-92521445D03*
%TD*%
%TO.C,MH5*%
X54090559Y-73385346D03*
%TD*%
M02*
