%TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*%
%TF.CreationDate,2025-11-17T00:26:10-08:00*%
%TF.ProjectId,back_plate_44,6261636b-5f70-46c6-9174-655f34342e6b,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2025-11-17 00:26:10*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,5.100000*%
G04 APERTURE END LIST*
D10*
%TO.C,MH1*%
X90481621Y-47334597D03*
%TD*%
%TO.C,MH2*%
X127121621Y-46334597D03*
%TD*%
%TO.C,MH3*%
X143283582Y-98055133D03*
%TD*%
%TO.C,MH4*%
X104359859Y-92856279D03*
%TD*%
%TO.C,MH5*%
X73555893Y-78600027D03*
%TD*%
M02*
