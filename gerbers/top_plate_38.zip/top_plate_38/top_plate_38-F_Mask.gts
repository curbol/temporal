%TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*%
%TF.CreationDate,2025-11-16T22:25:59-08:00*%
%TF.ProjectId,top_plate_38,746f705f-706c-4617-9465-5f33382e6b69,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2025-11-16 22:25:59*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.300000*%
G04 APERTURE END LIST*
D10*
%TO.C,MH1*%
X90481621Y-47334597D03*
%TD*%
%TO.C,MH2*%
X127121621Y-46334597D03*
%TD*%
%TO.C,MH3*%
X143283582Y-98055133D03*
%TD*%
%TO.C,MH4*%
X104359859Y-92856279D03*
%TD*%
%TO.C,MH5*%
X73555893Y-78600027D03*
%TD*%
M02*
