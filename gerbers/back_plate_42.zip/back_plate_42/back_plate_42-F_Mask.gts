%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*%
%TF.CreationDate,2026-08-24T22:59:00-07:00*%
%TF.ProjectId,back_plate_42,6261636b-5f70-46c6-9174-655f34322e6b,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-24 22:59:00*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.300000*%
G04 APERTURE END LIST*
D10*
%TO.C,MH3*%
X263966131Y-184777683D03*
%TD*%
%TO.C,MH2*%
X237589872Y-126585966D03*
%TD*%
%TO.C,MH1*%
X201139872Y-120635966D03*
%TD*%
%TO.C,MH5*%
X164554425Y-153460789D03*
%TD*%
%TO.C,MH4*%
X227419872Y-169585966D03*
%TD*%
M02*
