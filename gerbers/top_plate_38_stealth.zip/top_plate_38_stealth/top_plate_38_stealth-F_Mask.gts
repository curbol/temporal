%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5-1-g226df246f3*%
%TF.CreationDate,2026-09-06T23:58:59-07:00*%
%TF.ProjectId,top_plate_38_stealth,746f705f-706c-4617-9465-5f33385f7374,1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5-1-g226df246f3) date 2026-09-06 23:58:59*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.300000*%
G04 APERTURE END LIST*
D10*
%TO.C,MH1*%
X201139872Y-120635966D03*
%TD*%
%TO.C,MH2*%
X237589872Y-126585966D03*
%TD*%
%TO.C,MH3*%
X263966131Y-184777683D03*
%TD*%
%TO.C,MH4*%
X227419872Y-169585966D03*
%TD*%
%TO.C,MH5*%
X181888239Y-141765191D03*
%TD*%
M02*
